﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Models;
using OTMSService.Models;

namespace AuthenticationService.Service
{
    public interface IAuthService
    {
        bool RegisterUser(User user);
        User LoginUser(string userId, string password);
        bool IsUserExists(string UserId);

        EventDetail RegisterEvent(EventDetail eventObj);
        EventRegister RegisterUserEvent(EventRegister eventObj);

        List<User> ViewUserList();
        List<EventDetail> ViewEventList();
        List<EventRegister> EventRegister();

    }
}
