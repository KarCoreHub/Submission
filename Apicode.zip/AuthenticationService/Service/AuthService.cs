﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Exceptions;
using AuthenticationService.Models;
using AuthenticationService.Repository;
using OTMSService.Models;

namespace AuthenticationService.Service
{
    public class AuthService : IAuthService
    {
        private readonly IAuthRepository repository;
        
        public AuthService(IAuthRepository _repository)
        {
            this.repository = _repository;
        }
   

        public bool IsUserExists(string UserId)
        {
            var user = this.repository.FindUserById(UserId);
            if (user != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }      

        public User LoginUser(string UserId, string Password)
        {
            var user = this.repository.LoginUser(UserId, Password);
            if (user != null)
            {
                return user;
            }
            else
            {
                //User with this id {userId} and password {password} does not exist
                throw new UserNotFoundException("User with this id "+UserId+ " and password "+ Password+" does not exist");
            }
        }

                       
        public bool RegisterUser(User user)
        {
            var isResult = this.repository.RegisterUser(user);

            if (isResult)
                return isResult;
            else
                throw new UserNotCreatedException("User with this id "+user.UserId+" already exists");
        }

        public EventRegister RegisterUserEvent(EventRegister eventObj)
        {
            return  this.repository.RegisterUserEvent(eventObj);                  
        }

        public EventDetail RegisterEvent(EventDetail eventObj)
        {
            return this.repository.RegisterEvent(eventObj);        
        }

        public List<User> ViewUserList()
        {
            return this.repository.ViewUser();
        }

        public List<EventDetail> ViewEventList()
        {
            return this.repository.ViewEvents();
        }

        public List<EventRegister> EventRegister()
        {
            return this.repository.ViewEventRegisters();
        }
    }
}
