﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuthenticationService.Models;
using OTMSService.Models;

namespace AuthenticationService.Repository
{
    public class AuthRepository : IAuthRepository
    {
        private readonly IAuthenticationContext _context;
        public AuthRepository(IAuthenticationContext context)
        {
            _context = context;
        }
        

        public User FindUserById(string userId)
        {
            var _user = _context.Users.FirstOrDefault(u => u.UserId == userId);
            return _user;
        }

        public Vehicle FindVehicleById(string vehicleId)
        {
            var _vehicle= _context.Vehicles.FirstOrDefault(u => u.Number == vehicleId);
            return _vehicle;
        }

        public User LoginUser(string userId, string password)
        {
            var _user = _context.Users.FirstOrDefault(u => u.UserId == userId && u.Password == password);
            return _user;
        }

        public bool RegisterUser(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
            return true;
        }

        public EventRegister RegisterUserEvent(EventRegister eventObj)
        {
            _context.EventRegister.Add(eventObj);
            _context.SaveChanges();
            return eventObj;
        }

        public EventDetail RegisterEvent(EventDetail eventObj)
        {
           _context.Events.Add(eventObj);
           _context.SaveChanges();
            return eventObj;
        }

        public List<EventDetail> ViewEvents()
        {
            return _context.Events.ToList<EventDetail>();
        }

        public List<User> ViewUser()
        {
            return _context.Users.ToList<User>();
        }

        public List<EventRegister> ViewEventRegisters()
        {
            return _context.EventRegister.ToList<EventRegister>();
        }
    }
}
