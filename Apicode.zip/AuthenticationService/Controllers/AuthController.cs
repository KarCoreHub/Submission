﻿using AuthenticationService.Exceptions;
using AuthenticationService.Models;
using AuthenticationService.Service;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using OTMSService.Models;
using System;
using System.Collections.Generic;

namespace AuthenticationService.Controllers
{
    [Route("auth")]
    public class AuthController : Controller
    {
        private readonly IAuthService _service;       

        public AuthController(IAuthService service)
        {
            this._service = service;                     
        }
        

        //this method will be called by the client app with the user object for getting the JWT token
        [HttpPost]
        [Route("register")] //auth/register
        public IActionResult Register([FromBody]User user)
        {
            try
            {
                if (_service.IsUserExists(user.UserId) == true)
                {
                    return StatusCode(409, "A user already exists with this id");
                }
                else
                {
                    user.AddedDate = DateTime.Now;
                    _service.RegisterUser(user);
                    return Created("Created", true);                   
                }
            }
            catch (UserNotCreatedException eobj)
            {
                return StatusCode(500, eobj.Message);
               // return Conflict();
            }
        }

        
        [HttpPost]
        [Route("registerEvent")] //auth/registerEvent
        public IActionResult RegisterEvent([FromBody]EventDetail eventObj)
        {
            try
            {
                eventObj.AddedDate = DateTime.Now;
                eventObj.Active = true;
                _service.RegisterEvent(eventObj);
                return Created("Created", true);                
            }
            catch (EventNotCreatedException eobj)
            {
                return StatusCode(500, eobj.Message);
            }
        }

        [HttpPost]
        [Route("registerUserEvent")] //auth/registerUserEvent
        public IActionResult RegisterUserEvent([FromBody]EventRegister eventObj)
        {
            try
            {
                _service.RegisterUserEvent(eventObj);
                return Created("Created", true);
            }
            catch (EventNotCreatedException eobj)
            {
                return StatusCode(500, eobj.Message);
            }
        }

        [HttpGet]
        [Route("ViewUser")] //auth/register
        public List<User> ViewUserList()
        {
            List<User> tObj;
            try
            {
                tObj = _service.ViewUserList();                
            }
            catch (Exception eobj)
            {
                throw eobj;
            }
            return tObj;
        }

        [HttpGet]
        [Route("ViewEvents")] //auth/ViewEvents
        public List<EventDetail> ViewEventsList()
        {
            List<EventDetail> tObj;
            try
            {
                tObj = _service.ViewEventList();
            }
            catch (EventNotFoundException eobj)
            {
                throw eobj;
            }
            return tObj;
        }

        [HttpGet]
        [Route("ViewEventRegisters")] //auth/ViewEventRegisters
        public List<EventRegister> ViewEventRegistersList()
        {
            List<EventRegister> tObj; 
            try
            {
                tObj = _service.EventRegister();
            }
            catch (Exception eobj)
            {
                throw eobj;
            }
            return tObj;
        }

        [HttpGet]
        [Route("ViewEventWithUserId")] //auth/ViewEventWithUserId
        public List<EventRegister> ViewEventWithUserId()
        {
            List<EventRegister> tObj = new List<EventRegister>();
            List<EventRegister> finalList = new List<EventRegister>();
            List<User> userObj = new List<User>();
            List<EventDetail> eventList = new List<EventDetail>();
            try
            {
                tObj = _service.EventRegister();
                userObj = _service.ViewUserList();
                eventList = _service.ViewEventList();

                foreach (EventRegister regObj in tObj)
                {
                    EventRegister rObj = new EventRegister();
                    EventDetail regTest = eventList.Find(t => t.EventId == regObj.EventId);
                    User uObj = userObj.Find(t => t.UserId == regObj.UserId);
                    rObj.EventId = regTest.EventId + "-" + regTest.EventName + "-" + regTest.EventDetails + "-" + regTest.EventLocation + "-" + regTest.EventDate.ToShortDateString();
                    rObj.UserId = uObj.UserId + "-" + uObj.FirstName + "-" + uObj.LastName;
                    finalList.Add(rObj);
                }
            }
            catch (Exception eobj)
            {
                throw eobj;
            }
            return finalList;
        }


        //this method will be called by the client app with the user object for getting the JWT token
        [HttpPost]      
        [Route("login")]
        public IActionResult Login([FromBody]User user)
        {
            try
            {
                string userId = user.UserId;
                string password = user.Password;
                user.AddedDate = DateTime.Now;
                ITokenGenerator _tokengenerator = new TokenGenerator();
                User _user = _service.LoginUser(userId, password);

                //calling the function for the JWT token for respecting user
                string value = _tokengenerator.GetJWTToken(user.UserId,_user.Type);              
                //returning the token to the consumer app
                return Ok(value);
            }
            catch (UserNotFoundException eobj)
            {
                throw eobj;
            }            
        }

        [HttpPost]
        [Route("GetUserType")]
        public IActionResult GetUserType([FromBody]User user)
        {
            try
            {
                string userId = user.UserId;
                string password = user.Password;
                user.AddedDate = DateTime.Now;
             
                User _user = _service.LoginUser(userId, password);

                var response = new
                {
                    token = new string(_user.Type)
                };

                //convert into the json by serialing the response object
                return Ok(JsonConvert.SerializeObject(response));
            }
            catch (UserNotFoundException eobj)
            {
                throw eobj;
            }            
        }           

    }
}