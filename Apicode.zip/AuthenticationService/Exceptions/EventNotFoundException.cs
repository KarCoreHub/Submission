﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationService.Exceptions
{
    public class EventNotFoundException : ApplicationException
    {
        public EventNotFoundException() { }
        public EventNotFoundException(string message) : base(message) { }
    }
}
