﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using OTMSService.Models;

namespace AuthenticationService.Models
{
    public interface IAuthenticationContext
    {
        DbSet<User> Users { get; set; }
        DbSet<Travel> Trips { get; set; }
        DbSet<Vehicle> Vehicles { get; set; }
        DbSet<EventDetail> Events { get; set; }
        DbSet<EventRegister> EventRegister { get; set; }
        int SaveChanges();
    }
}
