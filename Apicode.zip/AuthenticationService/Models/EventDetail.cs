﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OTMSService.Models
{    
    [Table("EventDetail")]
    public class EventDetail
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        [JsonProperty(PropertyName = "eventid")]
        public string EventId { get; set; }        
        [JsonProperty(PropertyName = "eventname")]
        public string EventName { get; set; }
        [JsonProperty(PropertyName = "eventlocation")]
        public string EventLocation { get; set; }
        [JsonProperty(PropertyName = "eventdetails")]
        public string EventDetails { get; set; }
        [JsonProperty(PropertyName = "eventdate")]
        public DateTime EventDate { get; set; }
        [JsonProperty(PropertyName = "addeddate")]
        public DateTime AddedDate { get; set; }        
        [JsonProperty(PropertyName = "active")]
        public bool Active { get; set; }
    }
}
