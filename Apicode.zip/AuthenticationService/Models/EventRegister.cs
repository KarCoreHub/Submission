﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace OTMSService.Models
{

    [Table("EventRegister")]
    public class EventRegister
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
       
        [JsonProperty(PropertyName = "eventid")]
        public string EventId { get; set; }
        [JsonProperty(PropertyName = "userid")]
        public string UserId { get; set; }      
        public DateTime AddedDate { get; set; }
        [JsonProperty(PropertyName = "active")]
        public bool Active { get; set; }
    }
}

